<?php
// Text
$_['heading_title']     = 'TemplateMonster Social List';