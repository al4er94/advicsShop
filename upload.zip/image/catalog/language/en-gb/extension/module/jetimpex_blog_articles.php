<?php

// Heading 
$_['heading_title']        = 'Blog';

$_['text_date_format']     = 'd F Y';

$_['text_popular_all']     = 'From The Blog';
$_['text_latest_all']      = 'Latest from the blog';
$_['text_button_continue'] = 'Read More';
$_['text_comments']        = ' Comments';
$_['text_comment']         = ' Comment';
$_['text_published']         = 'Published on ';
$_['text_posted']         = 'Posted ';
$_['text_by']         = 'by ';

$_['text_no_result']       = 'No Result!';

?>