<?php
// Heading
$_['heading_title_color'] = 'JETIMPEX Color Switcher';
$_['title']         = 'The customization tool allows you to make color changes in your theme';
?>